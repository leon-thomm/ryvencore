class Location:
    PACKAGE_PATH = None
